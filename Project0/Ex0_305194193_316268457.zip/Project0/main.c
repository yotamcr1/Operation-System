#include<stdio.h>
void main()
{
	printf("Our IDs are: 305194193_316268457\n");
}